package com.example.shoppinglistapplication;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Actionbar title
        ActionBar actionBar = getSupportActionBar();
        actionBar.setTitle("First Activity");


        //Edit Text
        EditText editTextUserName = findViewById(R.id.editTextUserName);
        EditText editTextPassword = findViewById(R.id.editTextPassword);

        //Button
        Button mSaveBtn = findViewById(R.id.btnRegister);

        //Button click listener
        mSaveBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick (View view) {

                //Get data from edit text
                String name = editTextUserName.getText().toString();
                String password = editTextPassword.getText().toString();

                //Activity intent
                Intent intent = new Intent(MainActivity.this, SecondActivity.class);
                intent.putExtra("NAME",name);
                startActivity(intent);



            }



        });
        }


  //  }

    public void OnRegisterBtnClick (View view){

      /*  TextView txtErrorLength = findViewById(R.id.textWarning);
        TextView txtErrorSpace = findViewById(R.id.textWarning2);

        EditText editTextUserName = findViewById(R.id.editTextUserName);
        EditText editTextPassword = findViewById(R.id.editTextPassword);

        if (editTextUserName.length() < 6){

            txtErrorLength.setText("Username must be more than 6 characters");
        }

        if (editTextPassword.length() < 6){

            txtErrorLength.setText("Password must be more than 6 characters");
        }



       /* public static boolean containsWhiteSpace(final String pass) {
            pass = editTextPassword.toString();
            return CharMatcher.whitespace().matchesAnyOf(pass);
            
        }
                    if (editTextPassword.contains("") ){

            txtErrorSpace.setText("Password must not have a space");
        }

*/



    }
}