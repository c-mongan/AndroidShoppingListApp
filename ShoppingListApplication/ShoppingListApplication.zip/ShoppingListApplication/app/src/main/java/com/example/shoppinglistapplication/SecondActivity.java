package com.example.shoppinglistapplication;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class SecondActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);


        //Actionbar title
        ActionBar actionBar = getSupportActionBar();
        actionBar.setTitle("Second Activity");

        //Intent to get data
        Intent intent = getIntent();
        String name = intent.getStringExtra("NAME");

        //TextView
        TextView mResultTv = findViewById(R.id.resultTv);

        //Set Text
        mResultTv.setText("Welcome : "+name);
    }
}